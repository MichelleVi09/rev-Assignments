package com.day3;

public class Bike extends Vehicle{
	String type = "bike";
	private double discount;
	
	public Bike(String vehicleNumber, String model, int ratePerDay, int days, double disocunt) {
		super();
		setVehicle(vehicleNumber, model, ratePerDay, days);
		this.discount = discount; 
	}

	@Override
	public double calculateRent(int ratePerDay, int days) {
		// TODO Auto-generated method stub
		return super.calculateRent(ratePerDay, days) * (1- discount);
	}

	@Override
	public String displayDetails() {
		// TODO Auto-generated method stub
		return type + " | " + getVehicleNumber() + " | " + getModel()
 + " | " + getRatePerDay() + " | " + getDays() + " | " + calculateRent(getRatePerDay(), getDays());	}
	

}

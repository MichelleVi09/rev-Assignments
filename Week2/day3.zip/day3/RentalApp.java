
package com.day3;

import java.util.Scanner;

public class RentalApp {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int numVehicles;

        // Get number of vehicles
        while (true) {

            System.out.print("Enter number of vehicles: ");

            try {
                numVehicles = Integer.parseInt(scanner.nextLine().trim());

                if (numVehicles > 0) {
                    break;
                }

                System.out.println("Please enter a number greater than 0.");

            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }

        Vehicle[] vehicles = new Vehicle[numVehicles];

        // Get details for each vehicle
        for (int i = 0; i < numVehicles; i++) {

            int vehicleType;

            while (true) {

                System.out.print("Enter type (1-Car, 2-Bike): ");

                try {
                    vehicleType = Integer.parseInt(scanner.nextLine().trim());

                    if (vehicleType == 1 || vehicleType == 2) {
                        break;
                    }

                    System.out.println("Invalid vehicle type. Please enter 1 or 2.");

                } catch (NumberFormatException e) {
                    System.out.println("Please enter 1 or 2.");
                }
            }

            System.out.print("Enter Vehicle Number: ");
            String vehicleNumber = scanner.nextLine();

            System.out.print("Enter Model: ");
            String model = scanner.nextLine();

            System.out.print("Enter Rate per Day: ");
            int ratePerDay = Integer.parseInt(scanner.nextLine());

            System.out.print("Enter Days: ");
            int days = Integer.parseInt(scanner.nextLine());

            if (vehicleType == 1) {

                System.out.print("Enter Insurance per Day: ");
                double insuranceCharge = Double.parseDouble(scanner.nextLine());

                vehicles[i] = new Car(
                    vehicleNumber, model, ratePerDay,
                    days, insuranceCharge
                );

            } else {

                vehicles[i] = new Bike(
                    vehicleNumber, model, ratePerDay,
                    days, 0.10
                );
            }
        }

        // Display rental details
        double totalRent = 0;

        System.out.println("--- Rental Details ---");

        for (Vehicle vehicle : vehicles) {

            System.out.println(vehicle.displayDetails());

            totalRent += vehicle.calculateRent(
                vehicle.getRatePerDay(),
                vehicle.getDays()
            );
        }

        System.out.println("Total Rent Collected: " + totalRent);

        scanner.close();
    }
}


package com.day3;

public class Car extends Vehicle{
	String type = "car";
	private double insuranceCharge; 
	public Car(String vehicleNumber, String model, int ratePerDay, int days, double insuranceCharge) {
		super();
		setVehicle(vehicleNumber, model, ratePerDay, days);
		this.insuranceCharge = insuranceCharge;
	}
	
	@Override
	public double calculateRent(int ratePerDay, int days) {
		// TODO Auto-generated method stub
		return super.calculateRent(ratePerDay, days) + (insuranceCharge * days);
	}

	@Override
	public String displayDetails() {
		// TODO Auto-generated method stub
		return type + " | " + getVehicleNumber() + " | " + getModel()
 + " | " + getRatePerDay() + " | " + getDays() + " | " + calculateRent(getRatePerDay(), getDays());	}

}

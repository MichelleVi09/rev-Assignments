package com.day3;

public class Vehicle {
	private String vehicleNumber;
	private String model;
	private int ratePerDay;
	private int days;
	
	public double calculateRent(int ratePerDay, int days) {
		return ratePerDay * days; 
	}
	public String displayDetails() {
		return vehicleNumber + " | " + model
                + " | Days: " + days
                + " | Rent: " + calculateRent(ratePerDay, days);
	}
	

	public String getVehicleNumber() {
		return vehicleNumber;
		
	}
	public String getModel() {
		return model;
		
	}
	public int getRatePerDay() {
		return ratePerDay;
	}
	public int getDays() {
		return days;
	}
	public void setVehicle(String vehicleNumber, String model, int ratePerDay, int days) {
		this.vehicleNumber = vehicleNumber;
		this.model = model;
		this.ratePerDay = ratePerDay;
		this.days = days; 
		}
	
	
	
}

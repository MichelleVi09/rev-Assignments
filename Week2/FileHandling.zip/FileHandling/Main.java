package com.FileHandling;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.lang.ClassNotFoundException;

public class Main {
    public static void main(String[] args) {
        //creates an array of 5 Employee objects
        Employee[] employees = new Employee[5];

        //initializes employee objects
        employees[0] = new Employee(101, "John Smith", "IT", 50000);
        employees[1] = new Employee(102, "Sarah Jones", "HR", 45000);
        employees[2] = new Employee(103, "David Brown", "Finance", 55000);
        employees[3] = new Employee(104, "Emily Davis", "Marketing", 48000);
        employees[4] = new Employee(105, "Michael Wilson", "IT", 60000);

        //write the complete array to a file
        try {
            FileOutputStream fileOutput = new FileOutputStream("employees.dat");
            ObjectOutputStream objectOutput = new ObjectOutputStream(fileOutput);
            objectOutput.writeObject(employees);
            objectOutput.close();
            System.out.println("Employee objects saved successfully!");
        } catch (IOException e) {
            System.out.println("Error writing employee objects: " + e.getMessage());
        }
        //read the employee array from the file
        try {
            FileInputStream fileInput = new FileInputStream("employees.dat");
            ObjectInputStream objectInput = new ObjectInputStream(fileInput);
            Employee[] retrievedEmployees = (Employee[]) objectInput.readObject();
            objectInput.close();

            // Display retrieved employee details
            System.out.println("\n--- Retrieved Employee Details ---");
            for (Employee employee : retrievedEmployees) {
                System.out.println(employee);
                System.out.println("---------------------------");
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error reading employee objects: " + e.getMessage());
        }
    }
}


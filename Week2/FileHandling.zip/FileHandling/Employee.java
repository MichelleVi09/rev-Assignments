
package com.FileHandling;
import java.io.Serializable;

public class Employee implements Serializable {

    private static final long serialVersionUID = 1L;

    //attributes for employee
    private int empId;
    private String empName;
    private String department;
    private double salary;

    //constructor
    public Employee(int empId, String empName,
                    String department, double salary) {

        this.empId = empId;
        this.empName = empName;
        this.department = department;
        this.salary = salary;
    }

    //displays employee details
    @Override
    public String toString() {

        return "Employee ID: " + empId
                + "\nEmployee Name: " + empName
                + "\nDepartment: " + department
                + "\nSalary: " + salary;
    }
}


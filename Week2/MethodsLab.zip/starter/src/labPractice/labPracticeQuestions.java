package labPractice;

public class labPracticeQuestions {

	public static void main(String[] args) {
		//PART 1: DATA TYPES
		printProfile("Asha", 21, 5.6, true, 'A');
		printProfile("Ravi", 30, 5.9, false, 'B');
		System.out.println(average(1, 2, 2));
		System.out.println("\n");
		System.out.println(fitsInByte(127));
		System.out.println(fitsInByte(128));
		System.out.println(fitsInByte(-129));
		System.out.println("\n");
		
		//PART 2: WRAPPER CLASS
		System.out.println(addTexts("12", "30"));
		System.out.println("\n");
		System.out.println(boxTwice(21));
		System.out.println("\n");
		describe(10);
		System.out.println("\n");
		Integer a = 127;
		Integer b = 127;
		System.out.println(a + ": equals=" + sameValue(a, b) + " ==" + (a == b));
		System.out.println("\n");
		
		//PART 3: CASTING
		System.out.println(truncate(9.99));
		System.out.println(truncate(-9.99));
		System.out.println("\n");
		System.out.println(widen(7));
		overflowDemo();
		System.out.println("\n");
		System.out.println(shiftLetter('a', 2));
		System.out.println("\n");
		
		//PART 4: OVERLOADING:
		describeValue(5);
		describeValue(2.5);
		describeValue("hi");
		describeValue('A');
		describeValue(5L);
		System.out.println("\n");
		
		
		//PART 5: VALUE VS REFERENCE TYPES
		int x = 1;
		tryChange(x);
		System.out.println("x = "+ x);
		System.out.println("\n");
		
		StringBuilder sb = new StringBuilder("Hi");
		appendBang(sb);
		System.out.println(sb);
		System.out.println("\n");
		
		StringBuilder s = new StringBuilder("Hi");
        replaceBuilder(s);
        System.out.println(s);
		
        String st = "java";
        shout(st);
        System.out.println(st);
		
        
        //PART 6: REFERENCE VARIABLES:
        StringBuilder catBuilder = new StringBuilder("cat");
        StringBuilder sameBuilder = catBuilder;
        sameBuilder.append("s");
        System.out.println(catBuilder);
        System.out.println("\n");
        compareRefs();
        System.out.println("\n");
        System.out.println(safeLength(null));
        System.out.println(safeLength("hello"));
        
        
        // PART 7: STRING BASICS
        System.out.println(initials("ashu", "jauhari"));
        System.out.println(clean("     HeLLo "));
        System.out.println(isPalindromeWord("Level"));
        System.out.println(isPalindromeWord("Java"));
        System.out.println(maskEmail("asha@mail.com"));
        System.out.println("\n");
        
        // PART 8: STRINGBUILDER AND STRINGBUFFER
        System.out.println(buildCsv("a", "b", "c"));
        System.out.println(edit("Hello World"));
        System.out.println("\n");
        //comparing 
        System.out.println("String +=      : " + timeJoin(false) + " ns");
        System.out.println("StringBuilder : " + timeJoin(true) + " ns");
        System.out.println("\n");
        System.out.println(safeAppend(new StringBuffer("Hi"), " there"));
        System.out.println("\n");
        
        // PART 9: CAPSTONE
        System.out.println(formatReceipt("Asha", 3, 9.99));
        System.out.println(formatReceipt("Ravi", 2, 4.5));
       
		
		
        // SECTION B: PRACTICE PROBLEMS

        // Problem 1: Temperature converter
        System.out.println(toFahrenheit(0));
        System.out.println(toFahrenheit(37.5));
        System.out.println(toFahrenheit(-40));
        System.out.println("\n");

        // Problem 2: Percentage
        System.out.println(percent(45, 60));
        System.out.println(percent(1, 3));
        System.out.println("\n");

        // Problem 3: Number formats
        System.out.println(describeInt(255));
        System.out.println(describeInt(8));
        System.out.println("\n");

        // Problem 4: Failed swap
        int swapX = 1;
        int swapY = 2;
        swap(swapX, swapY);
     	System.out.println("outside: x=" + swapX + " y=" + swapY);
     	System.out.println("\n");

     	// Problem 5: Title for a name
     	StringBuilder name = new StringBuilder("Rao");
     	addTitle(name);
     	System.out.println(name);
     	String nameString = "Rao";
     	addTitleToString(nameString); // result ignored
     	System.out.println(nameString);
     	System.out.println(addTitleToString(nameString));
     	System.out.println("\n");

     	// Problem 6: Character counter and capitalizer
     	System.out.println(countChar("banana", 'a'));
     	System.out.println(countChar("banana", 'z'));
     	System.out.println(capitalize("jAVA"));
     	System.out.println("\n");

     	// Problem 7: Padding and repeating
     	System.out.println(padLeft("42", 5, '0'));
     	System.out.println(padLeft("12345", 3, '0'));
     	System.out.println(joinWithDash("ab", 3));
     	System.out.println(joinWithDash("x", 1));
     	System.out.println("\n");

     	// Problem 8: Rounding
     	System.out.println(roundHalfUp(2.5));
     	System.out.println(roundHalfUp(2.4));
     	System.out.println(roundHalfUp(7.0));
     	System.out.println("\n");
     
     	// Problem 9: Overflow
     	System.out.println(factorialInt(5));
     	System.out.println(factorialLong(5));
     	System.out.println(factorialInt(13));
     	System.out.println(factorialLong(13));
     	System.out.println(factorialLong(20));
     	System.out.println("\n");

     	// Problem 10: Text summary
     	System.out.println(summarize("Hello World"));
     	System.out.println(summarize("Sky"));
		
		
	}
	
	// START OF PART 1
	public static void printProfile(String name, int age, double height, boolean student, char grade){
		System.out.println("Name: " + name);
		System.out.println("Age: " + age);
		System.out.println("Height: " + height);
		System.out.println("Student: " + student);
		System.out.println("Grade: " + grade);
		System.out.println("\n");
		
	}
	
	public static double average(int a, int b, int c) {
		double average =  (a+b+c)/3.0;
		return average; 
	}
	
	public static boolean fitsInByte(int value) {
		if ((value >= -128) && value <=127) {
			return true;
		}
		else {
			return false;
		}
	}
	
	// END OF PART 1
	
	
	
	
	//START OF PART 2
	public static int addTexts(String a, String b) {
		int a_int = Integer.parseInt(a);
		int b_int = Integer.parseInt(b);
		
		return a_int + b_int;
	}
	
	public static Integer boxTwice(int x) {
		return Integer.valueOf(x * 2);

	}
	
	public static void describe(Integer n) {
		System.out.println("Binary: " + Integer.toBinaryString(n));
		System.out.println("Max: " + Integer.MAX_VALUE);
		System.out.println("Compare with 10.5: "+ Double.compare(n, 10.5));	
	}
	public static boolean sameValue(Integer a, Integer b) {
		return a.equals(b);
	}
	
	//END OF PART 2
	
	
	
	
	//START OF PART 3
	public static int truncate(double d) {
		return (int) d;
	}
	
	public static double widen(int i) {
		return i;
	}
	
	public static void overflowDemo() {
		int big = 130;
		byte b = (byte) big;
		System.out.println(b);
	}
	
	public static char shiftLetter(char c, int by) {
		return (char) (c+by);
	}
	//END OF PART 3
	
	
	
	
	//START OF PART 4:
	public static void describeValue(int a) {
		System.out.println("int: " + a);
	}
	public static void describeValue(double b) {
		System.out.println("double: " + b);
	}
	public static void describeValue(char c) {
	    System.out.println("char: " + c);
	}
	public static void describeValue(String str) {
		System.out.println("String: " + str);
	}
	//END OF PART 4:
	
	
	
	//START OF PART 5:
	public static void tryChange(int n) {
		n = 99;
	}
	
	public static void appendBang(StringBuilder sb) {
		sb.append("!");
	}
	
	public static void replaceBuilder(StringBuilder sb) {
        sb = new StringBuilder("New");
    }
	
	public static void shout(String s) {
	    s = s.toUpperCase();
	}
	//END OF PART 5
	
	

	// START OF PART 6

	public static void compareRefs() {

	    String s1 = "java";
	    String s2 = "java";
	    String s3 = new String("java");

	    System.out.println(s1 == s2);
	    System.out.println(s1 == s3);
	    System.out.println(s1.equals(s3));
	}

	public static int safeLength(String s) {

	    if (s == null) {
	        return -1;
	    }

	    return s.length();
	}

	//END OF PART 6
	
	
	
	// START OF PART 7

	public static String initials(String first, String last) {
	    return (first.substring(0, 1) + last.substring(0, 1))
	            .toUpperCase();
	}

	public static String clean(String raw) {
	    return raw.trim().toLowerCase();
	}

	public static boolean isPalindromeWord(String w) {
	    String reversed = new StringBuilder(w).reverse().toString();
	    return w.equalsIgnoreCase(reversed);
	}

	public static String maskEmail(String email) {
	    int at = email.indexOf("@");
	    String name = email.substring(0, at);
	    String domain = email.substring(at);

	    return name.substring(0, 1) + "*".repeat(name.length() - 1) + domain;
	}

	// END OF PART 7
	
	
	// START OF PART 8
	public static String buildCsv(String a, String b, String c) {
	    StringBuilder sb = new StringBuilder();
	    sb.append(a);
	    sb.append(",");
	    sb.append(b);
	    sb.append(",");
	    sb.append(c);
	    return sb.toString();
	}

	public static String edit(String text) {
	    StringBuilder sb = new StringBuilder(text);
	    sb.insert(0, "[");
	    sb.append("]");
	    sb.replace(7, 12, "Java");
	    sb.deleteCharAt(6);
	    return sb.toString();
	}

	public static long timeJoin(boolean useBuilder) {
	    long start = System.nanoTime();
	    if (useBuilder == false) {
	        String s = "";
	        for (int i = 0; i < 20000; i++) {
	            s += "x";
	        }
	    } else {
	        StringBuilder sb = new StringBuilder();
	        for (int i = 0; i < 20000; i++) {
	            sb.append("x");
	        }
	    }
	    long end = System.nanoTime();
	    return end - start;
	}

	public static String safeAppend(StringBuffer sb, String part) {
	    sb.append(part);
	    return sb.toString();
	}
	// END OF PART 8
	
	
	// START OF PART 9
	public static String formatReceipt(String customer, int quantity, double unitPrice) {
	    double total = quantity * unitPrice;
	    int whole = (int) total;
	    StringBuilder sb = new StringBuilder();
	    sb.append("Customer: ").append(customer.toUpperCase());
	    sb.append("\nQty: ").append(quantity);
	    sb.append(" | Price: ").append(unitPrice);
	    sb.append("\nTotal: ").append(total);
	    sb.append(" (whole: ").append(whole).append(")");
	    return sb.toString();
	}
	// END OF PART 9
	
	
	//PROBLEM 1: TEMP CONVERTER
	public static double toFahrenheit(double celsius) {
	    return celsius * 9 / 5 + 32;
	}
	
	//PROBLEM 2: PERCENTAGE
	public static int percent(int obtained, int total) {
	    double result = (obtained * 100.0) / total;
	    return (int) result;
	}
	
	//PROBLEM 3: NUMBER FORMATS 
	public static String describeInt(int n) {
	    return n + " -> binary " + Integer.toBinaryString(n)
	            + ", hex " + Integer.toHexString(n)
	            + ", octal " + Integer.toOctalString(n);
	}
	
	//PROBLEM 4: FAILED SWAP
	public static void swap(int a, int b) {
	    int temp = a;
	    a = b;
	    b = temp;
	    System.out.println("inside: a=" + a + " b=" + b);
	}
	
	//PROBLEM 5: TITLE FOR A NAME 
	public static void addTitle(StringBuilder name) {
	    name.insert(0, "Dr. ");
	}

	public static String addTitleToString(String name) {
	    return "Dr. " + name;
	}
	
	//PROBLEM 6: CHAR COUNTER AND CAPITALIZER 
	public static int countChar(String s, char c) {
	    int count = 0;
	    for (int i = 0; i < s.length(); i++) {
	        if (s.charAt(i) == c) {
	            count++;
	        }
	    }
	    return count;
	}

	public static String capitalize(String word) {
	    return word.substring(0, 1).toUpperCase()
	            + word.substring(1).toLowerCase();
	}
	
	//PROBLEM 7: PADDING AND REPEATING
	public static String padLeft(String s, int width, char fill) {
	    StringBuilder sb = new StringBuilder(s);
	    while (sb.length() < width) {
	        sb.insert(0, fill);
	    }
	    return sb.toString();
	}

	public static String joinWithDash(String s, int times) {
	    StringBuilder sb = new StringBuilder();
	    for (int i = 0; i < times; i++) {

	        if (i > 0) {
	            sb.append("-");
	        }
	        sb.append(s);
	    }
	    return sb.toString();
	}
	
	//PROBLEM 8: ROUNDING:
	public static int roundHalfUp(double d) {
	    return (int) (d + 0.5);
	}
	
	//PROBLEM 9: OVERFLOW
	public static int factorialInt(int n) {
	    int result = 1;
	    for (int i = 1; i <= n; i++) {
	        result *= i;
	    }
	    return result;
	}

	public static long factorialLong(int n) {
	    long result = 1;
	    for (int i = 1; i <= n; i++) {
	        result *= i;
	    }
	    return result;
	}
	
	//PROBLEM 10: TEXT SUMMARY
	public static int countVowels(String s) {
	    int count = 0;
	    for (int i = 0; i < s.length(); i++) {
	        char c = Character.toLowerCase(s.charAt(i));
	        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
	            count++;
	        }
	    }
	    return count;
	}

	public static String summarize(String text) {
	    StringBuilder sb = new StringBuilder();
	    sb.append("Length: ").append(text.length());
	    sb.append(" | Upper: ").append(text.toUpperCase());
	    sb.append(" | Vowels: ").append(countVowels(text));
	    return sb.toString();
	}

}

package ExceptionHandling;

public class Student {
	String name;
	int attendance;
	int marks; 
	
	public Student(String name, int attendance) {
		this.name = name;
		this.attendance = attendance; 
	}
}

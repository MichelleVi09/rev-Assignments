package ExceptionHandling;

public class AttendanceShortageException extends Exception {
    public AttendanceShortageException(String message) {
        super(message);
    }
}

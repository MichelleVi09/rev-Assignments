/* original code given
package com.smartstore.billing;
import java.util.Scanner;

public class SalaryCalculator {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Read and validate the employee ID
        System.out.print("Enter Employee ID: ");
        String employeeId = scanner.nextLine().trim();

        while (employeeId.isEmpty()) {
            System.out.println("Employee ID cannot be empty.");
            System.out.print("Enter Employee ID: ");
            employeeId = scanner.nextLine().trim();
        }

        // Read and validate the employee name
        System.out.print("Enter Employee Name: ");
        String employeeName = scanner.nextLine().trim();

        while (employeeName.isEmpty()) {
            System.out.println("Employee name cannot be empty.");
            System.out.print("Enter Employee Name: ");
            employeeName = scanner.nextLine().trim();
        }

        // Read and validate the basic salary
        double basicSalary;

        while (true) {
            System.out.print("Enter Basic Salary: ");

            if (!scanner.hasNextDouble()) {
                System.out.println("Please enter a valid numeric salary.");
                scanner.nextLine();
                continue;
            }

            basicSalary = scanner.nextDouble();

            if (basicSalary < 0) {
                System.out.println("Basic salary cannot be negative.");
            } else {
                break;
            }
        }

        // Calculate the employee's salary details
        double hra = calculateHra(basicSalary);
        double da = calculateDa(basicSalary);
        double grossSalary = calculateGrossSalary(basicSalary, hra, da);
        double professionalTax = calculateProfessionalTax(grossSalary);
        double netSalary = calculateNetSalary(grossSalary, professionalTax);

        displaySalaryDetails(
            employeeId,
            employeeName,
            basicSalary,
            hra,
            da,
            grossSalary,
            professionalTax,
            netSalary
        );

        scanner.close();
    }

    // HRA = 20% of basic salary
    public static double calculateHra(double basicSalary) {
        return basicSalary * 20 / 100;
    }

    // DA = 10% of basic salary
    public static double calculateDa(double basicSalary) {
        return basicSalary * 10 / 100;
    }

    // Gross salary = basic salary + HRA + DA
    public static double calculateGrossSalary(
            double basicSalary,
            double hra,
            double da) {
        return basicSalary + hra + da;
    }

    // Deduct Rs. 200 only when gross salary is above Rs. 20,000
    public static double calculateProfessionalTax(double grossSalary) {
        if (grossSalary > 20000) {
            return 200;
        }

        return 0;
    }

    // Net salary = gross salary - professional tax
    public static double calculateNetSalary(
            double grossSalary,
            double professionalTax) {
        return grossSalary - professionalTax;
    }

    // Display employee and salary information
    public static void displaySalaryDetails(
            String employeeId,
            String employeeName,
            double basicSalary,
            double hra,
            double da,
            double grossSalary,
            double professionalTax,
            double netSalary) {

        System.out.println("\n========== Employee Salary Details ==========");
        System.out.println("Employee ID: " + employeeId);
        System.out.println("Employee Name: " + employeeName);
        System.out.printf("Basic Salary: Rs. %.2f%n", basicSalary);
        System.out.printf("HRA: Rs. %.2f%n", hra);
        System.out.printf("DA: Rs. %.2f%n", da);
        System.out.printf("Gross Salary: Rs. %.2f%n", grossSalary);
        System.out.printf("Professional Tax: Rs. %.2f%n", professionalTax);
        System.out.printf("Net Salary: Rs. %.2f%n", netSalary);
        System.out.println("==============================================");
    }
}
*/

//refactored code
package com.smartstore.billing;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Scanner;

public class SalaryCalculator {

    private static final BigDecimal HRA_PERCENTAGE =
            new BigDecimal("20");
    private static final BigDecimal DA_PERCENTAGE =
            new BigDecimal("10");
    private static final BigDecimal PERCENTAGE_DIVISOR =
            new BigDecimal("100");
    private static final BigDecimal PROFESSIONAL_TAX_LIMIT =
            new BigDecimal("20000");
    private static final BigDecimal PROFESSIONAL_TAX =
            new BigDecimal("200");

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String employeeId = readEmployeeId(scanner);
        String employeeName = readEmployeeName(scanner);
        BigDecimal basicSalary = readBasicSalary(scanner);

        BigDecimal hra = calculateHra(basicSalary);
        BigDecimal da = calculateDa(basicSalary);
        BigDecimal grossSalary =
                calculateGrossSalary(basicSalary, hra, da);
        BigDecimal professionalTax =
                calculateProfessionalTax(grossSalary);
        BigDecimal netSalary =
                calculateNetSalary(grossSalary, professionalTax);

        displaySalaryDetails(
                employeeId,
                employeeName,
                basicSalary,
                hra,
                da,
                grossSalary,
                professionalTax,
                netSalary);

        scanner.close();
    }

    public static String readEmployeeId(Scanner scanner) {
        while (true) {
            System.out.print("Enter Employee ID: ");
            String employeeId = scanner.nextLine().trim();

            if (!employeeId.isEmpty()) {
                return employeeId;
            }

            System.out.println("Employee ID cannot be empty.");
        }
    }

    public static String readEmployeeName(Scanner scanner) {
        while (true) {
            System.out.print("Enter Employee Name: ");
            String employeeName = scanner.nextLine().trim();

            if (!employeeName.isEmpty()) {
                return employeeName;
            }

            System.out.println("Employee name cannot be empty.");
        }
    }

    public static BigDecimal readBasicSalary(Scanner scanner) {
        while (true) {
            System.out.print("Enter Basic Salary: ");
            String input = scanner.nextLine().trim();

            try {
                BigDecimal basicSalary = new BigDecimal(input);

                if (basicSalary.compareTo(BigDecimal.ZERO) < 0) {
                    System.out.println(
                            "Basic salary cannot be negative.");
                } else {
                    return basicSalary;
                }
            } catch (NumberFormatException exception) {
                System.out.println(
                        "Please enter a valid numeric salary.");
            }
        }
    }

    // HRA = 20% of the basic salary.
    public static BigDecimal calculateHra(BigDecimal basicSalary) {
        return basicSalary
                .multiply(HRA_PERCENTAGE)
                .divide(PERCENTAGE_DIVISOR, 2, RoundingMode.HALF_UP);
    }

    // DA = 10% of the basic salary.
    public static BigDecimal calculateDa(BigDecimal basicSalary) {
        return basicSalary
                .multiply(DA_PERCENTAGE)
                .divide(PERCENTAGE_DIVISOR, 2, RoundingMode.HALF_UP);
    }

    // Gross salary = basic salary + HRA + DA.
    public static BigDecimal calculateGrossSalary(
            BigDecimal basicSalary,
            BigDecimal hra,
            BigDecimal da) {
        return basicSalary.add(hra).add(da);
    }

    // Professional tax is deducted only when gross salary is above ₹20,000.
    public static BigDecimal calculateProfessionalTax(
            BigDecimal grossSalary) {

        if (grossSalary.compareTo(PROFESSIONAL_TAX_LIMIT) > 0) {
            return PROFESSIONAL_TAX;
        }

        return BigDecimal.ZERO;
    }

    // Net salary = gross salary - professional tax.
    public static BigDecimal calculateNetSalary(
            BigDecimal grossSalary,
            BigDecimal professionalTax) {
        return grossSalary.subtract(professionalTax);
    }

    public static void displaySalaryDetails(
            String employeeId,
            String employeeName,
            BigDecimal basicSalary,
            BigDecimal hra,
            BigDecimal da,
            BigDecimal grossSalary,
            BigDecimal professionalTax,
            BigDecimal netSalary) {

        System.out.println("\n========== Employee Salary Details ==========");
        System.out.println("Employee ID: " + employeeId);
        System.out.println("Employee Name: " + employeeName);
        System.out.println("Basic Salary: Rs. " +
                formatAmount(basicSalary));
        System.out.println("HRA: Rs. " + formatAmount(hra));
        System.out.println("DA: Rs. " + formatAmount(da));
        System.out.println("Gross Salary: Rs. " +
                formatAmount(grossSalary));
        System.out.println("Professional Tax: Rs. " +
                formatAmount(professionalTax));
        System.out.println("Net Salary: Rs. " +
                formatAmount(netSalary));
        System.out.println("==============================================");
    }

    public static String formatAmount(BigDecimal amount) {
        return amount
                .setScale(2, RoundingMode.HALF_UP)
                .toString();
    }
}

 


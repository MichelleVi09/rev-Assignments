package com.smartstore.billing;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class BillingApplicationTest {

    @Test
    void testDiscountBelow1000() {
        double discount = BillingApplication.calculateDiscount(800);

        assertEquals(0.0, discount, 0.001);
    }

    @Test
    void testDiscountAtExactly5000() {
        double discount = BillingApplication.calculateDiscount(5000);

        assertEquals(500.0, discount, 0.001);
    }


    @Test
    void testDiscountAtExactly1000() {
        // 5% of Rs. 1,000 = Rs. 50
        double discount = BillingApplication.calculateDiscount(1000);

        assertEquals(50.00, discount, 0.001);
    }

    @Test
    void testDiscountAt4999() {
        // 5% of Rs. 4,999 = Rs. 249.95
        double discount = BillingApplication.calculateDiscount(4999);

        assertEquals(249.95, discount, 0.001);
    }


    @Test
    void testDiscountAbove5000() {
        // 10% of Rs. 7,000 = Rs. 700
        double discount = BillingApplication.calculateDiscount(7000);

        assertEquals(700.00, discount, 0.001);
    }
}




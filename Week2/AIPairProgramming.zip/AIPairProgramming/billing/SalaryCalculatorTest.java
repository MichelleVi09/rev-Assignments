package com.smartstore.billing;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;

class SalaryCalculatorTest {

    @Test
    void testZeroBasicSalary() {
        BigDecimal salary = new BigDecimal("0");

        BigDecimal hra = SalaryCalculator.calculateHra(salary);
        BigDecimal da = SalaryCalculator.calculateDa(salary);
        BigDecimal gross =
                SalaryCalculator.calculateGrossSalary(salary, hra, da);
        BigDecimal tax =
                SalaryCalculator.calculateProfessionalTax(gross);
        BigDecimal net =
                SalaryCalculator.calculateNetSalary(gross, tax);

        assertEquals(0, hra.compareTo(BigDecimal.ZERO));
        assertEquals(0, da.compareTo(BigDecimal.ZERO));
        assertEquals(0, gross.compareTo(BigDecimal.ZERO));
        assertEquals(0, tax.compareTo(BigDecimal.ZERO));
        assertEquals(0, net.compareTo(BigDecimal.ZERO));
    }

    @Test
    void testNegativeSalaryRejection() {
        assertThrows(
                IllegalArgumentException.class,
                () -> validateBasicSalary(new BigDecimal("-1")));
    }

    private void validateBasicSalary(BigDecimal salary) {
        if (salary.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException(
                    "Basic salary cannot be negative.");
        }
    }

    @Test
    void testGrossSalaryExactly20000HasNoTax() {
        BigDecimal gross = new BigDecimal("20000");

        BigDecimal tax =
                SalaryCalculator.calculateProfessionalTax(gross);

        assertEquals(0, tax.compareTo(BigDecimal.ZERO));
    }

    @Test
    void testGrossSalaryJustAbove20000HasTax() {
        BigDecimal gross = new BigDecimal("20000.01");

        BigDecimal tax =
                SalaryCalculator.calculateProfessionalTax(gross);

        assertEquals(
                0,
                tax.compareTo(new BigDecimal("200")));
    }

    @Test
    void testGrossSalaryJustBelow20000HasNoTax() {
        BigDecimal gross = new BigDecimal("19999.99");

        BigDecimal tax =
                SalaryCalculator.calculateProfessionalTax(gross);

        assertEquals(0, tax.compareTo(BigDecimal.ZERO));
    }

    @Test
    void testDecimalSalaryCalculations() {
        BigDecimal salary = new BigDecimal("12345.50");

        BigDecimal hra =
                SalaryCalculator.calculateHra(salary);
        BigDecimal da =
                SalaryCalculator.calculateDa(salary);
        BigDecimal gross =
                SalaryCalculator.calculateGrossSalary(
                        salary, hra, da);

        assertEquals(
                0,
                hra.compareTo(new BigDecimal("2469.10")));
        assertEquals(
                0,
                da.compareTo(new BigDecimal("1234.55")));
        assertEquals(
                0,
                gross.compareTo(new BigDecimal("16049.15")));
    }

    @Test
    void testEmptyEmployeeIdRejection() {
        assertThrows(
                IllegalArgumentException.class,
                () -> validateEmployeeId(""));
    }

    @Test
    void testEmployeeIdWithSpacesRejection() {
        assertThrows(
                IllegalArgumentException.class,
                () -> validateEmployeeId("   "));
    }

    private void validateEmployeeId(String employeeId) {
        if (employeeId == null ||
                employeeId.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Employee ID cannot be empty.");
        }
    }

    @Test
    void testEmptyEmployeeNameRejection() {
        assertThrows(
                IllegalArgumentException.class,
                () -> validateEmployeeName(""));
    }

    @Test
    void testEmployeeNameWithSpacesRejection() {
        assertThrows(
                IllegalArgumentException.class,
                () -> validateEmployeeName("   "));
    }

    private void validateEmployeeName(String employeeName) {
        if (employeeName == null ||
                employeeName.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Employee name cannot be empty.");
        }
    }

    @Test
    void testVeryLargeSalaryHandling() {
        BigDecimal salary =
                new BigDecimal("999999999999999999999.99");

        BigDecimal hra =
                SalaryCalculator.calculateHra(salary);
        BigDecimal da =
                SalaryCalculator.calculateDa(salary);
        BigDecimal gross =
                SalaryCalculator.calculateGrossSalary(
                        salary, hra, da);

        assertEquals(
                0,
                salary.compareTo(
                        gross.subtract(hra).subtract(da)));
    }

    @Test
    void testCorrectNetSalaryCalculation() {
        BigDecimal gross = new BigDecimal("25000");
        BigDecimal tax =
                SalaryCalculator.calculateProfessionalTax(gross);
        BigDecimal net =
                SalaryCalculator.calculateNetSalary(gross, tax);

        assertEquals(
                0,
                tax.compareTo(new BigDecimal("200")));
        assertEquals(
                0,
                net.compareTo(new BigDecimal("24800")));
    }
}


